// Protocol detection for WebSockets
const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
const host = window.location.host;
const telemetryUrl = `${protocol}//${host}/ws/telemetry`;
const lidarUrl = `${protocol}//${host}/ws/lidar`;

let teleWs, lidarWs;
let isConnected = false;

function connectWebsockets() {
    // --- Telemetry WebSocket ---
    teleWs = new WebSocket(telemetryUrl);
    
    teleWs.onopen = () => {
        isConnected = true;
        console.log("✅ Telemetry connected");
    };
    
    teleWs.onmessage = (event) => {
        const data = JSON.parse(event.data);
        updateUI(data);
    };
    
    teleWs.onclose = () => {
        isConnected = false;
        console.log("❌ Telemetry disconnected. Retrying...");
        setTimeout(connectWebsockets, 3000);
    };

    // --- LiDAR WebSocket ---
    lidarWs = new WebSocket(lidarUrl);
    lidarWs.onmessage = (event) => {
        const data = JSON.parse(event.data);
        updateLidar(data);
    };
}

// --- UI Element Selectors ---
const batteryEl = document.getElementById('battery-val');
const steeringEl = document.getElementById('steering-val');
const speedEl = document.getElementById('speed-val');

function updateUI(state) {
    if (state.battery !== undefined) {
        batteryEl.textContent = `${state.battery.toFixed(1)}%`;
        batteryEl.style.color = state.battery < 20 ? '#ef4444' : '';
    }
    
    if (state.steering_angle !== undefined) {
        steeringEl.textContent = `${state.steering_angle.toFixed(1)}°`;
    }
    
    if (state.speed !== undefined) {
        speedEl.textContent = `${state.speed.toFixed(2)} m/s`;
    }
}

// --- LiDAR 3D Visualization ---
const lidarContainer = document.querySelector('.lidar-view');
const lidarPoints = [];
const NUM_POINTS = 360; // 360 points for a full circular scan

function initLidar() {
    for (let i = 0; i < NUM_POINTS; i++) {
        const pt = document.createElement('div');
        pt.className = 'lidar-point';
        lidarContainer.appendChild(pt);
        lidarPoints.push(pt);
    }
}

function updateLidar(distances) {
    const n = Math.min(distances.length, NUM_POINTS);
    distances.forEach((dist, i) => {
        if (i >= NUM_POINTS) return;
        
        // Map 0-360 degrees
        const angle = (i / distances.length) * Math.PI * 2 - Math.PI / 2;
        const maxDisplayDist = 4.0; // 4 meters max visible in panel
        
        // Scale distance to percentage (radius)
        const r = Math.min((dist / maxDisplayDist) * 45, 48); // cap at 48% center-to-edge
        
        const x = 50 + Math.cos(angle) * r;
        const y = 50 + Math.sin(angle) * r;
        
        const pt = lidarPoints[i];
        pt.style.left = `${x}%`;
        pt.style.top = `${y}%`;
        
        // Visual feedback for proximity
        if (dist < 0.1) {
            pt.style.opacity = 0;
        } else {
            pt.style.opacity = 1;
            pt.style.backgroundColor = dist < 0.6 ? '#ef4444' : '#38bdf8';
            pt.style.boxShadow = dist < 0.6 ? '0 0 10px #ef4444' : '0 0 5px #38bdf8';
        }
    });
}

// --- Offline Fallback Logic ---
setInterval(() => {
    if (!isConnected) {
        const t = performance.now() / 1000;
        updateUI({
            battery: 100 - (t % 100) / 10,
            steering_angle: Math.sin(t) * 25,
            speed: 1.2 + Math.sin(t/2) * 0.5
        });
        
        // Local mock lidar animation
        if (lidarPoints.length > 0) {
            const mockDists = Array.from({length: NUM_POINTS}, (_, i) => 
                1.5 + Math.sin(i * 0.1 + t) * 0.5 + Math.random() * 0.2);
            updateLidar(mockDists);
        }
    }
}, 100);

// Initialize
initLidar();
connectWebsockets();

