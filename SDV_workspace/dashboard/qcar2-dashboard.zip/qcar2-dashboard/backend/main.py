import asyncio
from fastapi import FastAPI, WebSocket
from fastapi.responses import StreamingResponse
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware
import json
import math
import random
import time
import os
import cv2
import numpy as np
import threading
import sys

# Quanser path setup - pop DISPLAY for headless operation
os.environ.pop("DISPLAY", None)
os.environ.pop("XAUTHORITY", None)
QUANSER_LIB_PATH = '/home/nvidia/Documents/Quanser/0_libraries/python'
if os.path.exists(QUANSER_LIB_PATH) and QUANSER_LIB_PATH not in sys.path:
    sys.path.insert(0, QUANSER_LIB_PATH)

class HardwareManager:
    def __init__(self):
        self.has_hardware = False
        self.qcar = None
        self.cameras = None
        self.realsense = None
        self.latest_frames = [None] * 4
        self.latest_realsense = None
        self.telemetry = {
            "battery": 100.0,
            "steering_angle": 0.0,
            "speed": 0.0,
            "mode": "SIMULATION"
        }
        self.active = True
        
        try:
            from pal.products.qcar import QCar, QCarCameras, QCarRealSense
            self.qcar = QCar()
            self.cameras = QCarCameras(
                frameWidth=640, frameHeight=480, frameRate=30,
                enableFront=True, enableLeft=True, enableRight=True, enableBack=True
            )
            self.realsense = QCarRealSense(mode='RGB', frameWidthRGB=640, frameHeightRGB=480)
            self.has_hardware = True
            self.telemetry["mode"] = "REAL"
            print("✅ QCar 2 Hardware Initialized Successfully")
        except Exception as e:
            print(f"⚠️ Hardware not found: {e}. Initializing in Simulation Mode.")

    def update_loop(self):
        while self.active:
            if self.has_hardware:
                try:
                    # Sync hardware state
                    self.cameras.readAll()
                    for i in range(4):
                        if self.cameras.csi[i] is not None:
                            self.latest_frames[i] = self.cameras.csi[i].imageData
                    
                    if self.realsense:
                        self.realsense.read_RGB()
                        self.latest_realsense = self.realsense.imageBufferRGB
                    
                    # Read telemetry via read_write_std (sending zero commands to just read)
                    # battery and other info is typically in the return or internal buffers
                    # For now, we simulate the values if exact API calls for battery aren't yielding results
                    # based on common QCar patterns.
                    self.telemetry["battery"] -= 0.0001 
                    # If we had a gamepad or autonomous node running, we'd pull those values here
                except Exception as e:
                    print(f"Hardware loop error: {e}")
            else:
                # Simulation Mode Telemetry
                t = time.time()
                self.telemetry["battery"] = max(0.0, 100.0 - (t % 1000) / 100.0)
                self.telemetry["steering_angle"] = math.sin(t) * 25.0
                self.telemetry["speed"] = 1.2 + math.sin(t / 2) * 0.5
            
            time.sleep(0.03) # ~30Hz

    def stop(self):
        self.active = False
        if self.cameras: self.cameras.terminate()
        if self.qcar: self.qcar.terminate()

# Global HW Manager
hw = HardwareManager()
threading.Thread(target=hw.update_loop, daemon=True).start()

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/video/csi/{cam_id}")
async def video_feed(cam_id: int):
    def gen_frames():
        while True:
            frame = hw.latest_frames[cam_id] if cam_id < 4 else None
            
            if frame is None:
                # Generate a black frame with a label if no real frame is available
                frame = np.zeros((480, 640, 3), dtype=np.uint8)
                cv2.putText(frame, f"CSI Camera {cam_id} (No Signal)", (150, 240), 
                            cv2.FONT_HERSHEY_SIMPLEX, 0.8, (255, 255, 255), 2)
            
            ret, buffer = cv2.imencode('.jpg', frame)
            if ret:
                yield (b'--frame\r\n'
                       b'Content-Type: image/jpeg\r\n\r\n' + buffer.tobytes() + b'\r\n')
            time.sleep(0.04) # Limit FPS for streaming

    return StreamingResponse(gen_frames(),
                    media_type='multipart/x-mixed-replace; boundary=frame')

@app.get("/video/realsense")
async def realsense_feed():
    def gen_frames():
        while True:
            frame = hw.latest_realsense
            if frame is None:
                frame = np.zeros((480, 640, 3), dtype=np.uint8)
                cv2.putText(frame, "RealSense RGB (No Signal)", (150, 240), 
                            cv2.FONT_HERSHEY_SIMPLEX, 0.8, (255, 255, 255), 2)
            ret, buffer = cv2.imencode('.jpg', frame)
            if ret:
                yield (b'--frame\r\n'
                       b'Content-Type: image/jpeg\r\n\r\n' + buffer.tobytes() + b'\r\n')
            time.sleep(0.04)
    return StreamingResponse(gen_frames(), media_type='multipart/x-mixed-replace; boundary=frame')

@app.get("/video/lane")
async def lane_feed():
    def gen_frames():
        while True:
            # Placeholder for lane detection overlay
            # In a real scenario, this would come from a ROS2 subscription or a shared buffer with the perception node
            frame = np.zeros((480, 640, 3), dtype=np.uint8)
            cv2.line(frame, (200, 480), (300, 300), (0, 255, 0), 5)
            cv2.line(frame, (440, 480), (340, 300), (0, 255, 0), 5)
            cv2.putText(frame, "Lane Detection Preview", (150, 200), 
                        cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 255, 0), 2)
            ret, buffer = cv2.imencode('.jpg', frame)
            yield (b'--frame\r\n'
                   b'Content-Type: image/jpeg\r\n\r\n' + buffer.tobytes() + b'\r\n')
            time.sleep(0.06)
    return StreamingResponse(gen_frames(), media_type='multipart/x-mixed-replace; boundary=frame')

@app.websocket("/ws/telemetry")
async def websocket_endpoint(websocket: WebSocket):
    await websocket.accept()
    try:
        while True:
            await websocket.send_text(json.dumps(hw.telemetry))
            await asyncio.sleep(0.1) # 10Hz telemetry
    except Exception:
        pass

@app.websocket("/ws/lidar")
async def lidar_endpoint(websocket: WebSocket):
    await websocket.accept()
    try:
        while True:
            # Send latest LiDAR distances
            # hw.telemetry could be updated to include lidar if we want it all in one, 
            # but separate WS is often better for high-bandwidth points
            if hw.has_hardware and hasattr(hw, 'latest_lidar'):
                await websocket.send_text(json.dumps(hw.latest_lidar))
            else:
                # Mock lidar points
                mock_points = [random.uniform(0.5, 5.0) for _ in range(40)]
                await websocket.send_text(json.dumps(mock_points))
            await asyncio.sleep(0.2) # 5Hz for LiDAR is plenty for the web view
    except Exception:
        pass

# Mount the frontend directory
current_dir = os.path.dirname(os.path.abspath(__file__))
frontend_path = os.path.abspath(os.path.join(current_dir, "..", "frontend"))
app.mount("/", StaticFiles(directory=frontend_path, html=True), name="frontend")

